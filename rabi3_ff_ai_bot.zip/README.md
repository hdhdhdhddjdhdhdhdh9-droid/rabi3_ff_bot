# rabi3_ff_bot — Telegram AI bot

This is a small Flask webhook bot for Render. It replies to `/start`, `/help`, and text messages using the Gemini API.

## Files
- `main.py` — bot application
- `requirements.txt` — Python dependencies

## Deploy on Render
1. Upload these files to a GitHub repository.
2. In Render, create **New → Web Service**, connect the repository.
3. Set **Runtime/Language: Python**.
4. Build command: `pip install -r requirements.txt`
5. Start command: `gunicorn main:app`
6. Select the **Free** instance if offered.
7. Add Environment Variables (Secrets):
   - `BOT_TOKEN` — token from BotFather (keep private)
   - `GEMINI_API_KEY` — key from Google AI Studio (keep private)
   - `WEBHOOK_SECRET` — create a random string of letters/numbers, 30+ characters
   - `RENDER_EXTERNAL_URL` — your Render service URL, e.g. `https://your-service.onrender.com`
8. Save/redeploy. On startup the app registers the Telegram webhook.
9. Open your Telegram bot and send `/start`.

## Notes
- Never commit API keys or bot tokens to GitHub.
- Free hosting and AI API quotas have limits; a free Render service may sleep when idle.
- If you previously shared the BotFather token publicly, revoke it in BotFather and use the new token.
